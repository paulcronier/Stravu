# Run Lab
1. Crée un dépôt GitHub (**privé** recommandé), pousse le contenu de ce dossier (`site/`, `scripts/`, `.github/`).
2. Settings → Pages → Source : **GitHub Actions**.
3. Settings → Secrets → Actions : `GARMIN_EMAIL`, `GARMIN_PASSWORD`.
4. Actions → « Sync Garmin & déploiement » → Run workflow. Le site se met à jour 2×/jour.
5. iPhone : Safari → Partager → « Sur l’écran d’accueil ».
