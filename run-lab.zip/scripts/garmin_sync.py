"""Synchronise Garmin Connect -> site/data/garmin.json (lancé par GitHub Actions)."""
import os, json, datetime as dt
from pathlib import Path
from garminconnect import Garmin

TOK = Path.home() / ".garminconnect"
api = Garmin(os.environ["GARMIN_EMAIL"], os.environ["GARMIN_PASSWORD"])
try:
    api.login(str(TOK))            # réutilise les tokens si présents
except Exception:
    api.login()
    api.garth.dump(str(TOK))

today = dt.date.today()
acts = []
for a in api.get_activities_by_date((today - dt.timedelta(days=120)).isoformat(), today.isoformat()):
    t = a.get("activityType", {}).get("typeKey", "")
    acts.append({
        "id": a["activityId"], "date": a["startTimeLocal"][:10], "name": a.get("activityName"),
        "type": t, "km": round(a.get("distance", 0) / 1000, 2), "sec": int(a.get("duration", 0)),
        "hr": a.get("averageHR"), "hrMax": a.get("maxHR"), "elev": a.get("elevationGain"),
        "te": a.get("aerobicTrainingEffect"), "load": a.get("activityTrainingLoad"),
    })
daily = []
for i in range(30):
    d = (today - dt.timedelta(days=i)).isoformat()
    row = {"date": d}
    try:
        s = api.get_stats(d); row["rhr"] = s.get("restingHeartRate"); row["steps"] = s.get("totalSteps")
        row["bb"] = s.get("bodyBatteryHighestValue")
    except Exception: pass
    try:
        sl = api.get_sleep_data(d)["dailySleepDTO"]; row["sleep"] = (sl.get("sleepScores") or {}).get("overall", {}).get("value")
        row["sleepH"] = round((sl.get("sleepTimeSeconds") or 0) / 3600, 1)
    except Exception: pass
    daily.append(row)
out = {"updated": dt.datetime.now().isoformat(timespec="minutes"), "demo": False, "activities": acts, "daily": daily}
Path("site/data/garmin.json").write_text(json.dumps(out, ensure_ascii=False))
print(len(acts), "activités")
